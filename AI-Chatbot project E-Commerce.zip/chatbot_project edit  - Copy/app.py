from flask import Flask, render_template, request, redirect, url_for, session, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
import mysql.connector
from mysql.connector import Error
from chat import get_response  # Import chatbot logic

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# Database connection helper
def get_db_connection():
    try:
        conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="chatbot"
        )
        return conn
    except Error as e:
        print(f"Error: {e}")
        return None

@app.route('/')
def home():
    if 'username' in session:
        return redirect(url_for('chat'))
    return render_template('home.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        confirm_password = request.form['confirm_password']

        if password != confirm_password:
            return "Passwords do not match. <a href='/signup'>Try again</a>"

        hashed_password = generate_password_hash(password)
        conn = get_db_connection()
        if conn:
            try:
                cursor = conn.cursor(dictionary=True)
                cursor.execute("SELECT * FROM user WHERE username = %s", (username,))
                existing_user = cursor.fetchone()
                
                if existing_user:
                    return "User already exists. <a href='/signup'>Try again</a>"

                cursor.execute("INSERT INTO user (username, password) VALUES (%s, %s)", (username, hashed_password))
                conn.commit()
                cursor.close()
                conn.close()
                session['username'] = username
                return redirect(url_for('chat'))
            except Error as e:
                return f"Database error: {e}"
    return render_template('signup.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        conn = get_db_connection()
        if conn:
            cursor = conn.cursor(dictionary=True)
            cursor.execute("SELECT * FROM user WHERE username = %s", (username,))
            user = cursor.fetchone()
            cursor.close()
            conn.close()

            if not user:
                return "User does not exist. <a href='/login'>Try again</a>"

            if check_password_hash(user['password'], password):
                session['username'] = username
                return redirect(url_for('chat'))
            else:
                return "Invalid password. <a href='/login'>Try again</a>"
    
    return render_template('login.html')

@app.route('/chat')
def chat():
    if 'username' not in session:
        return redirect(url_for('login'))
    return render_template('chat.html', username=session['username'])

@app.route('/chat-response', methods=['POST'])
def chat_response():
    if request.is_json:
        data = request.get_json()
        message = data.get('message', '')
        response = get_response(message)
        return jsonify({"response": response})
    return jsonify({"error": "Unsupported Media Type"}), 415

@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('home'))

if __name__ == '__main__':
    app.run(debug=True)
