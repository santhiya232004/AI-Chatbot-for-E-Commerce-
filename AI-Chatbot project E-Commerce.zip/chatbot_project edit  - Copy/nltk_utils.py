import nltk
import numpy as np
from nltk.stem.porter import PorterStemmer

nltk.download('punkt')

stemmer = PorterStemmer()

def tokenize(sentence):
    """Splits a sentence into words (tokens)."""
    return nltk.word_tokenize(sentence.lower())

def stem(word):
    """Reduces words to their root form."""
    return stemmer.stem(word.lower())

def bag_of_words(tokenized_sentence, words):
    """Converts a tokenized sentence into a bag of words vector."""
    sentence_words = [stem(word) for word in tokenized_sentence]
    bag = np.zeros(len(words), dtype=np.float32)
    for idx, w in enumerate(words):
        if w in sentence_words:
            bag[idx] = 1.0
    return bag
